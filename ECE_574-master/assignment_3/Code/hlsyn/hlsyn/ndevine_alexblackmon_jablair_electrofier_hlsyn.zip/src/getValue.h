//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#ifndef GETVALUE_H
#define GETVALUE_H


class GetValue {

public:
	double stringToDelay(std::string datatype, std::string datawidth);

	GetValue();
	~GetValue();
};


#endif /* getValue_h */