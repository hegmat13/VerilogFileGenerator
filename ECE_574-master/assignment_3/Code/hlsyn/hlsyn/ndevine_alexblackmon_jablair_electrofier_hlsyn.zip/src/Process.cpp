#include "Process.h"

#include <string>
#include <iostream>
#include <sstream>
#include <vector>
#include <map>
#include <set>
#include <iterator>

#include "getValue.h"
#include "dpgen.h"
#include "FDS.h"

using namespace std;


GetValue delays;

Process::Process()
{
}

Process::~Process()
{
}

int Process::parseNetlist(ifstream &netList, ofstream &verilogFile)
{
    int status = UNKNOWN_ERROR;
    string comment =  "//";
	vector<CircuitSignal> circuitVector;
	vector<CircuitComp> circuitCompVector;
	bool startComps = false;
	
	string currentIfOrElse = "none";
	
	ifStatement = false;
	ifLevel = 0;
	elseLevel = 0;
	
	for (string line; getline(netList, line); )
	{
		// first we will remove all comments from the line
		string::size_type commentIndex = line.find(comment);

		if (commentIndex != string::npos)
			line.erase(commentIndex, line.length());
		
		if(((line.find("input") != string::npos) || (line.find("output") != string::npos) || ((line.find("variable") != string::npos) && (line.find("=") == string::npos))
            || (line.find("register") != string::npos)) && !startComps)
		{
			//cout << line << endl;
			parseSignals(netList, circuitVector, line);
		}
		else
		{
			if(!line.empty())
			{	
				startComps = true;
				
				stringstream lineStream(line);
				
				if(line.find("+ 1") != string::npos)
				{	
					status = parseOneOperand(circuitVector, circuitCompVector, lineStream, "INC");
				}
				else if(line.find("- 1") != string::npos)
				{
					status = parseOneOperand(circuitVector, circuitCompVector, lineStream, "DEC");
				}
				else if(line.find("+") != string::npos)
				{	
					status = parseTwoOperands(circuitVector, circuitCompVector, lineStream, "ADD");
					
					//cout << circuitCompVector.at(0).type << " " << circuitCompVector.at(0).result << " " << circuitCompVector.at(0).operands.at(0) << " " << circuitCompVector.at(0).operands.at(1) << endl;
				
				}
				else if(line.find("-") != string::npos)
				{
					status = parseTwoOperands(circuitVector, circuitCompVector, lineStream, "SUB");	
				}			
				else if(line.find("*") != string::npos)
				{
					status = parseTwoOperands(circuitVector, circuitCompVector, lineStream, "MUL");
				}
				else if(line.find("/") != string::npos)
				{				
					status = parseTwoOperands(circuitVector, circuitCompVector, lineStream, "DIV");
				}
				else if(line.find("<<") != string::npos)
				{
					status = parseTwoOperands(circuitVector, circuitCompVector, lineStream, "SHL");
				}		
				else if(line.find(">>") != string::npos)
				{
					status = parseTwoOperands(circuitVector, circuitCompVector, lineStream, "SHR");
				}	
				else if(line.find("?") != string::npos)
				{
					status = parseMux(circuitVector, circuitCompVector, lineStream, "MUX");	
				}			
				else if(line.find("%") != string::npos)
				{	
					status = parseTwoOperands(circuitVector, circuitCompVector, lineStream, "MOD");
				}
				else if((line.find("<") != string::npos) || (line.find(">") != string::npos) || (line.find("==") != string::npos))
				{
					//NOTE: COMP will be stored as 5 operands in the following order
					// op1 will be 1st input, op2 will be 2nd input, op3 will be gt, op4 will be lt, op5 will be eq
					// if we are gt, op3 will have value, op4 and op5 will be 0 
					// ie if we have c = a == b, a will be op1, b will be op2, 0 will be op3, 0 will be op4, c will be op5
					// for extra help I will also put c in the result for the example above
					
					status = parseComp(circuitVector, circuitCompVector, lineStream, "COMP");
					//circuitComp.type = "COMP";
				}
				else if((line.find("&") != string::npos) || (line.find("^") != string::npos) || (line.find("#") != string::npos) 
					|| (line.find("$") != string::npos) || (line.find("@") != string::npos))
				{
					status = FAIL_OPERATOR;
					return status;
				}
				else if((line.find("if") != string::npos))
				{	
					//cout << line << endl;
					string ignoreIf, ignoreParen1, condition;
					lineStream >> ignoreIf >> ignoreParen1 >> condition;
					//cout << condition << endl;
					ifStatement = true;
					ifLevel++;
					
					for (std::vector<int>::size_type i = 0; i != circuitVector.size(); i++)
					{
						if(circuitVector.at(i).getCircuitSignalName() == condition)
						{
							//cout << circuitVector.at(i).getCircuitSignalName() << endl;
							circuitVector.at(i).setCircuitSignalIfCondition(true);
							circuitVector.at(i).setCircuitSignalIfConditionLevel(ifLevel);
							if(currentIfOrElse == "if")
							{
								circuitVector.at(i).setIfNestedWith(currentIfOrElse+to_string(ifLevel-1));
							}
							else if(currentIfOrElse == "else")
							{
								circuitVector.at(i).setIfNestedWith(currentIfOrElse+to_string(elseLevel));
							}
							
							//cout << circuitVector.at(i).getIfNestedWith() << endl;
						}
					}
					
					currentIfOrElse = "if";
				}
				else if((line.find("}") != string::npos) && elseLevel == 0)
				{
					ifStatement = false;
					ifLevel--;
				}
				else if(line.find("else") != string::npos)
				{
					currentIfOrElse = "else";
					
					elseLevel = ifLevel+1;
				}
				else if((line.find("}") != string::npos) && elseLevel > 0)
				{
					elseLevel--;
				}
				//REG?
				else
				{	
					//cout << line << endl;
					//status = parseOneOperand(circuitVector, circuitCompVector, lineStream, "REG");
				}
				
				
				if (status != SUCCESS)
				{
					return status;
				}
			}
		}
	}
	FDS fds(latency);
	fds.scheduleFDS(circuitCompVector);
	
	status = 1; // writeDeclarations(circuitVector, verilogFile);
	if(status == 1)
	{
		//writeStateMachineProc(circuitVector, circuitCompVector, verilogFile);
	}
	else
	{
		return status;
	}

	//cout << "Critical Path: " << CalculateCriticalPath(circuitCompVector) << "ns" <<endl;
	
	return status;
}

void Process::parseSignals(ifstream &netList, vector<CircuitSignal> &circuitVector, std::string &line)
{
	CircuitSignal circuitSignal;
	stringstream lineStream(line);
	string signal, dataType, variable, dataWidth;
	vector<string> variables;
	bool multipleVariables = false;
	
	lineStream >> signal >> dataType;
	lineStream >> variable;
	
	dataWidth = parseDataType(dataType);
	
	multipleVariables = parseVariable(variable, variables);
	
	//cout << variable << endl;
	
	while(multipleVariables) 
	{
		lineStream >> variable;
		multipleVariables = parseVariable(variable, variables);
		//cout << variable << endl;
	}
	
	for (std::vector<int>::size_type i = 0; i != variables.size(); i++)
	{
		circuitSignal.setCircuitSignalType(signal);
		circuitSignal.setCircuitSignalDataType(dataType);
		circuitSignal.setCircuitSignalWidth(dataWidth);
		circuitSignal.setCircuitSignalName(variables[i]);

		circuitVector.push_back(circuitSignal);
	}
	//cout << "Signal is: " << circuitVector.at(2).getCircuitSignalType() << " DataType is: " << circuitVector.at(2).getCircuitSignalDataType() << " Variable is: " << circuitVector.at(2).getCircuitSignalName() <<  " Width is: " << circuitVector.at(2).getCircuitSignalWidth() << endl;
	//cout << "Signal is: " << circuitVector.at(2).getCircuitSignalType() << " DataType is: " << circuitVector.at(2).getCircuitSignalDataType() << " Variable is: " << circuitVector.at(2).getCircuitSignalName() << endl;
	
}

bool Process::parseVariable(string variable, vector<string> &variables)
{
	string::size_type pos = variable.find(",");
	
	if(pos == string::npos)
	{
		variables.push_back(variable);
		
		return false;
	}
	else
	{
		variable = variable.erase(pos, variable.length());
		variables.push_back(variable);
		
		return true;
	}
}

string Process::parseDataType(string &dataType)
{
    string width;
	
	width = "invalid";
	
	string::size_type pos = dataType.find("Int");
	
    if(pos != string::npos)
	{
		width = dataType.substr(pos+3, dataType.length()); //create string which represents the data width after "Int"
	
		dataType = dataType.substr(0,pos+3); // change widthString to be just "Int" or "UInt" need to test
		
		//cout << width << " " << dataType << endl;
	}

	return width;

}

int Process::parseOneOperand(vector<CircuitSignal> &circuitVector, vector<CircuitComp> &circuitCompVector, stringstream &lineStream, string type)
{
	CircuitComp circuitComp;
	string result, equal, op, op1;
				
	lineStream >> result >> equal >> op1;
	
	circuitComp.type = type;

	circuitComp.enumType = stringToEnumType(type);
	
	circuitComp.comparatorOp = NOT_COMP;

	circuitComp.cycleTime = getCycleTime(type);
	
	// loop through entire circuit signal vector looking for any input/output/wire/reg within the 
	// component instantiation 
	// if you never found one of the values error out
	int numOperandsFound = 0;
	for (std::vector<int>::size_type i = 0; i != circuitVector.size(); i++)
	{					
		if((circuitVector.at(i).getCircuitSignalType() == "input") || (circuitVector.at(i).getCircuitSignalType() == "variable") 
			|| (circuitVector.at(i).getCircuitSignalType() == "output") || (circuitVector.at(i).getCircuitSignalType() == "register"))
		{
			if(circuitVector.at(i).getCircuitSignalName() == op1)
			{
				//found input/wire
				numOperandsFound++;
				
				circuitVector.at(i).setCircuitSignalPosition("op1");
				
				circuitComp.operands.push_back(circuitVector.at(i));
			}
			else if(circuitVector.at(i).getCircuitSignalName() == result)
			{
				numOperandsFound++;
				
				circuitVector.at(i).setCircuitSignalPosition("result");

                if (circuitVector.at(i).getCircuitSignalDataType().find('U') == string::npos)
                {
                    circuitComp.type = 'S' + type;
                }

				//add in getting delay
				
				circuitComp.width = circuitVector.at(i).getCircuitSignalWidth();
				circuitComp.delay = delays.stringToDelay(type, circuitComp.width);
				//circuitComp.delay += addDependentDelaysOneOP(circuitCompVector, op1);
				//cout << "delay: " << circuitComp.delay << endl;
				circuitComp.result = circuitVector.at(i);
				circuitComp.operands.push_back(circuitVector.at(i));
				//found output/wire
			}
		}
	}
	
	if(numOperandsFound != 2)
	{
		return FAIL_OPERAND;
	}
	else
	{
		// if(ifLevel > 0)
		// {
			// circuitComp.ifStatement = true;
		// }
		// else
		// {
			// circuitComp.ifStatement = false;
		// }
		
		circuitComp.elseStatementLevel = elseLevel;
		circuitComp.ifStatementLevel = ifLevel;
		circuitCompVector.push_back(circuitComp);
		
		return SUCCESS;
	}
}

int Process::parseTwoOperands(vector<CircuitSignal> &circuitVector, vector<CircuitComp> &circuitCompVector, stringstream &lineStream, string type)
{
	CircuitComp circuitComp;
	string result, equal, op, op1, op2;
				
	lineStream >> result >> equal >> op1 >> op >> op2;
	
	circuitComp.type = type;
	
	circuitComp.enumType = stringToEnumType(type);
	
	circuitComp.comparatorOp = NOT_COMP;

	circuitComp.cycleTime = getCycleTime(type);
	
	// loop through entire circuit signal vector looking for any input/output/wire/reg within the 
	// component instantiation 
	// if you never found one of the values error out
	int numOperandsFound = 0;
	for (std::vector<int>::size_type i = 0; i != circuitVector.size(); i++)
	{					
		if((circuitVector.at(i).getCircuitSignalType() == "input") || (circuitVector.at(i).getCircuitSignalType() == "variable") 
			|| (circuitVector.at(i).getCircuitSignalType() == "output") || (circuitVector.at(i).getCircuitSignalType() == "register"))
		{
			if(circuitVector.at(i).getCircuitSignalName() == op1)
			{
				//found input/wire
				numOperandsFound++;
				
				circuitVector.at(i).setCircuitSignalPosition("op1");
				
				circuitComp.operands.push_back(circuitVector.at(i));
			}
			else if(circuitVector.at(i).getCircuitSignalName() == op2)
			{
				//found input/wire
				numOperandsFound++;
				
				circuitVector.at(i).setCircuitSignalPosition("op2");
				
				circuitComp.operands.push_back(circuitVector.at(i));
			}
			else if(circuitVector.at(i).getCircuitSignalName() == result)
			{
				numOperandsFound++;
				
				circuitVector.at(i).setCircuitSignalPosition("result");
				
                if (circuitVector.at(i).getCircuitSignalDataType().find('U') == string::npos)
                {
                    circuitComp.type = 'S' + type;
                }

                //add in getting delay
				
				circuitComp.width = circuitVector.at(i).getCircuitSignalWidth();
				circuitComp.delay = delays.stringToDelay(type, circuitComp.width);
				//circuitComp.delay += addDependentDelaysTwoOP(circuitCompVector, op1, op2);
				//cout << "delay: " << circuitComp.delay << endl;
				circuitComp.result = circuitVector.at(i);
				circuitComp.operands.push_back(circuitVector.at(i));
				//found output/wire
			}
		}
	}
	
	if(numOperandsFound != 3)
	{
		return FAIL_OPERAND;
	}
	else
	{
		// if(inIfLevel > 0)
		// {
			// circuitComp.ifStatement = true;
		// }
		// else
		// {
			// circuitComp.ifStatement = false;
		// }
		
		circuitComp.elseStatementLevel = elseLevel;
		circuitComp.ifStatementLevel = ifLevel;
		circuitCompVector.push_back(circuitComp);
		
		return SUCCESS;
	}
}

int Process::parseComp(vector<CircuitSignal> &circuitVector, vector<CircuitComp> &circuitCompVector, stringstream &lineStream, string type)
{
	CircuitComp circuitComp;
	string result, equal, op1, op, op2;
	string width = "0";
				
	lineStream >> result >> equal >> op1 >> op >> op2;
	
	circuitComp.type = type;
	
	circuitComp.enumType = stringToEnumType(type);
	
	circuitComp.comparatorOp = NOT_COMP;

	circuitComp.cycleTime = getCycleTime(type);
	
	// loop through entire circuit signal vector looking for any input/output/wire/reg within the 
	// component instantiation 
	// if you never found one of the values error out
	int numOperandsFound = 0;
	for (std::vector<int>::size_type i = 0; i != circuitVector.size(); i++)
	{					
		if((circuitVector.at(i).getCircuitSignalType() == "input") || (circuitVector.at(i).getCircuitSignalType() == "variable") 
			|| (circuitVector.at(i).getCircuitSignalType() == "output") || (circuitVector.at(i).getCircuitSignalType() == "register"))
		{
			if(circuitVector.at(i).getCircuitSignalName() == op1)
			{
				//found input/wire
				numOperandsFound++;
				
				if(circuitVector.at(i).getCircuitSignalWidth() > width)
					width = circuitVector.at(i).getCircuitSignalWidth();
				
				circuitVector.at(i).setCircuitSignalPosition("op1");
				
				circuitComp.operands.push_back(circuitVector.at(i));
			}
			else if(circuitVector.at(i).getCircuitSignalName() == op2)
			{
				//found input/wire
				numOperandsFound++;
				
				if(circuitVector.at(i).getCircuitSignalWidth() > width)
					width = circuitVector.at(i).getCircuitSignalWidth();
				
				circuitVector.at(i).setCircuitSignalPosition("op2");
				
				circuitComp.operands.push_back(circuitVector.at(i));
			}
			else if(circuitVector.at(i).getCircuitSignalName() == result)
			{
				numOperandsFound++;
				
				circuitVector.at(i).setCircuitSignalPosition("result");
				
                if (circuitVector.at(i).getCircuitSignalDataType().find('U') == string::npos)
                {
                    circuitComp.type = 'S' + type;
                }

                //add in getting delay
				
				circuitComp.width = width;
				circuitComp.delay = delays.stringToDelay(type, circuitComp.width);
				//circuitComp.delay += addDependentDelaysTwoOP(circuitCompVector, op1, op2);
				//cout << "delay: " << circuitComp.delay << endl;
				circuitComp.result = circuitVector.at(i);
				circuitComp.operands.push_back(circuitVector.at(i));
				//found output/wire
			
			
				if( op == ">")
				{
					circuitComp.comparatorOp = GT;
					circuitVector.at(i).setCircuitSignalPosition("op3");
					circuitComp.operands.push_back(circuitVector.at(i));
				}
				else
				{
					CircuitSignal circuitSignal;
					circuitSignal.setCircuitSignalName("0");
					
					circuitComp.operands.push_back(circuitSignal);
				}
				
				if (op == "<")
				{
					circuitComp.comparatorOp = LT;
					circuitVector.at(i).setCircuitSignalPosition("op4");
					circuitComp.operands.push_back(circuitVector.at(i));
				}
				else
				{
					CircuitSignal circuitSignal;
					circuitSignal.setCircuitSignalName("0");
					
					circuitComp.operands.push_back(circuitSignal);
				}
				if (op == "==")
				{
					circuitComp.comparatorOp = EQ;
					circuitVector.at(i).setCircuitSignalPosition("op5");
					circuitComp.operands.push_back(circuitVector.at(i));
				}
				else
				{
					CircuitSignal circuitSignal;
					circuitSignal.setCircuitSignalName("0");
					
					circuitComp.operands.push_back(circuitSignal);
				}
			}
		}
	}
	
	if(numOperandsFound != 3)
	{
		return FAIL_OPERAND;
	}
	else
	{
		// if(inIfLevel > 0)
		// {
			// circuitComp.ifStatement = true;
		// }
		// else
		// {
			// circuitComp.ifStatement = false;
		// }
		
		circuitComp.elseStatementLevel = elseLevel;
		circuitComp.ifStatementLevel = ifLevel;
		circuitCompVector.push_back(circuitComp);
		
		return SUCCESS;
	}
}

int Process::parseMux(vector<CircuitSignal> &circuitVector, vector<CircuitComp> &circuitCompVector, stringstream &lineStream, string type)
{
	CircuitComp circuitComp;
	string result, equal, sel, op, op1, colon, op2;
				
	lineStream >> result >> equal >> sel >> op >> op1 >> colon >> op2;
	
	circuitComp.type = type;
	
	circuitComp.enumType = stringToEnumType(type);
	
	circuitComp.comparatorOp = NOT_COMP;

	circuitComp.cycleTime = getCycleTime(type);
	
	// loop through entire circuit signal vector looking for any input/output/wire/reg within the 
	// component instantiation 
	// if you never found one of the values error out
	int numOperandsFound = 0;
	for (std::vector<int>::size_type i = 0; i != circuitVector.size(); i++)
	{					
		if((circuitVector.at(i).getCircuitSignalType() == "input") || (circuitVector.at(i).getCircuitSignalType() == "variable") 
			|| (circuitVector.at(i).getCircuitSignalType() == "output") || (circuitVector.at(i).getCircuitSignalType() == "register"))
		{
			if(circuitVector.at(i).getCircuitSignalName() == sel)
			{
				//found input/wire
				numOperandsFound++;
				
				circuitVector.at(i).setCircuitSignalPosition("sel");
				
				circuitComp.operands.push_back(circuitVector.at(i));
			}
			else if(circuitVector.at(i).getCircuitSignalName() == op1)
			{
				//found input/wire
				numOperandsFound++;
				
				circuitVector.at(i).setCircuitSignalPosition("op1");
				
				circuitComp.operands.push_back(circuitVector.at(i));
			}
			else if(circuitVector.at(i).getCircuitSignalName() == op2)
			{
				//found input/wire
				numOperandsFound++;
				
				circuitVector.at(i).setCircuitSignalPosition("op2");
				
				circuitComp.operands.push_back(circuitVector.at(i));
			}
			else if(circuitVector.at(i).getCircuitSignalName() == result)
			{
				numOperandsFound++;
				
				circuitVector.at(i).setCircuitSignalPosition("result");
				
                if (circuitVector.at(i).getCircuitSignalDataType().find('U') == string::npos)
                {
                    circuitComp.type = 'S' + type;
                }

                //add in getting delay
				
				circuitComp.width = circuitVector.at(i).getCircuitSignalWidth();
				circuitComp.delay = delays.stringToDelay(type, circuitComp.width);
				//circuitComp.delay += addDependentDelaysMux(circuitCompVector, sel, op1, op2);
				//cout << "delay: " << circuitComp.delay << endl;
				circuitComp.result = circuitVector.at(i);
				circuitComp.operands.push_back(circuitVector.at(i));
				//found output/wire
			}
		}
	}
	
	if(numOperandsFound != 4)
	{
		return FAIL_OPERAND;
	}
	else
	{
		// if(inIfLevel > 0)
		// {
			// circuitComp.ifStatement = true;
		// }
		// else
		// {
			// circuitComp.ifStatement = false;
		// }
		
		circuitComp.elseStatementLevel = elseLevel;
		circuitComp.ifStatementLevel = ifLevel;
		circuitCompVector.push_back(circuitComp);
		
		return SUCCESS;
	}
}

int Process::writeDeclarations(vector<CircuitSignal> &signals, ofstream &verilogFile)
{
   /* int status = -1;
    int temp;
    list<string> declarations;
    stringstream lineStream;
    string lineOut;
    string moduleName;
    string signalWidth;
    string regType;

    // Verilog module name is the same as the filename without the extension
    string::size_type pos = verilogFilename.find(".v");
    if (pos == string::npos)
    {
        return FAIL_FILE_TYPE;
    }
    moduleName = verilogFilename.erase(pos, verilogFilename.length());

    // First line of Verilog file declares the time scale
    lineStream << "`timescale 1ns / 1ns";
    lineOut = lineStream.str();
    declarations.push_back(lineOut);

    // Next line is module declaration with ports
    lineStream << "module " << moduleName << "(Clk, Rst, Start, Done";
    for (vector<CircuitSignal>::iterator it = signals.begin(); it != signals.end(); ++it)
    {
        if ((it->getCircuitSignalType() == "input") || (it->getCircuitSignalType() == "output"))
        {
            lineStream << ", " << it->getCircuitSignalName();
        }
    }
    lineStream << ");";
    lineOut = lineStream.str();
    declarations.push_back(lineOut);

    // Inputs and outputs follow the declaration
    lineStream << "\t" << "input Clk, Rst, Start;";
    lineOut = lineStream.str();
    declarations.push_back(lineOut);

    lineStream << "\t" << "output reg Done;";
    lineOut = lineStream.str();
    declarations.push_back(lineOut);

    for (vector<CircuitSignal>::iterator it = signals.begin(); it != signals.end(); ++it)
    {
        if (it->getCircuitSignalType() == "input")
        {
            lineStream << "\tinput ";
        }
        else if (it->getCircuitSignalType() == "output")
        {
            lineStream << "\toutput reg ";
        }
        else
        {
            lineStream << "\treg ";
        }

        if (it->getCircuitSignalDataType() == "Int")
        {
            lineStream << "signed ";
        }

        temp = stoi(it->getCircuitSignalWidth(), nullptr, 10);
        if (temp != 1)
        {
            signalWidth = to_string(--temp);
            lineStream << "[" << signalWidth << " : 0] ";
        }

        declareCycleCounter(declarations);

        lineStream << it->getCircuitSignalName() << ";";
        lineOut = lineStream.str();
        declarations.push_back(lineOut);
    }

    // build state machine declaration
    declareStateMachine(declarations, components);

    // place all declarations in the Verilog file
    writeListToFile(list<string> &declarations, ofstream &verilogFile);

    // add empty line for readability
    verilogFile << '\n';

    status = SUCCESS;
    return status;*/
	return 1;
}

void Process::writeListToFile(list<string> &listToWrite, ofstream &outputFile)
{
   /* for (list<string>::iterator it = listToWrite.begin(); it != listToWrite.end(); ++it)
    {
        outputFile << *it << '\n';
    }*/
}

void Process::declareCycleCounter(list<string> &declarations)
{
    /*stringstream lineStream;
    string lineOut;
    int vecSize = static_cast<int>(ceil(log2(static_cast<double>(latency))));
    int msb = vecSize - 1;

    lineStream << "\treg [" << msb << ":0] CycleCnt;";
    lineOut = lineStream.str();
    declarations.push_back(lineOut);*/
}

void Process::declareStateMachine(list<string> &declarations, vector<CircuitComp> &components)
{
  /*  stringstream lineStream;
    string lineOut;

    // find out how many states are needed
    numStates = findNumStates(components);

    // define a parameter to enumerate the states
    declareStates(declarations);

    // declare the state machine
    lineStream << "\treg [" << numStates - 1 << ":0] State;";
    lineOut = lineStream.str();
    declarations.push_back(lineOut);*/
}

int Process::findNumStates(vector<CircuitComp> &components)
{
   /* bool foundEntry = false;

    // The number of states needed is equal to number of start times
    for (vector<CircuitComp>::iterator it = components.begin(); it != components.end(); ++it)
    {
        for (set<int>::iterator it2 = startTimeSet.begin(); (it2 != startTimeSet.end() && !foundEntry); ++it2)
        {
            if (it->timeframe[0] == *it2)
            {
                foundEntry = true;
            }
        }
        
        if (!foundEntry)
            startTimeSet.insert(it->timeframe[0]);

        foundEntry = false;
    }
    
    return startTimeSet.size();*/
	return 0;
}

void Process::declareStates(list<string> &declarations)
{
 /*   int vecSize = static_cast<int>(ceil(log2(static_cast<double>(startTimeSet.size() + 2))));
    int msb = vecSize - 1;
    int stateNum = 0;
    stringstream lineStream;
    string lineOut;

    // Declare parameter as a vector
    lineStream << "\tparameter [" << msb << ":0]";
    lineOut = lineStream.str();
    declarations.push_back(lineOut);
    
    // The first state will always be WAIT
    lineStream << "\t\tWAIT = " << vecSize << "'d" << stateNum << ",";
    lineOut = lineStream.str();
    declarations.push_back(lineOut);
    
    // Create the intermediate states (S0, S1, etc.)
    for (int i = 0; i < numStates; ++i)
    {
        lineStream << "\t\tS" << i << " = " << vecSize << "'d" << ++stateNum;
        lineOut = lineStream.str();
        declarations.push_back(lineOut);
    }

    // The last state will always be FINAL
    lineStream << "\t\tFINAL = " << vecSize << "'d" << ++stateNum << ",";
    lineOut = lineStream.str();
    declarations.push_back(lineOut);*/
}

void Process::writeStateMachineProc(vector<CircuitSignal> &signals, vector<CircuitComp> &components, ofstream &verilogFile)
{
/*    stringstream lineStream;
    string lineOut;
    list<string> stateMachine;

    // State machine is a synchronous process
    lineStream << "always @(posedge Clk) begin";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);

    // Reset all outputs and registers
    resetStateMachine(signals, stateMachine);

    // Create state machine Verilog code
    createStateMachine(components, signals, stateMachine);

    // Write state machine to Verilog file
    writeListToFile(stateMachine, verilogFile);*/
}

void Process::resetStateMachine(vector<CircuitSignal> &signals, list<string> &stateMachine)
{
   /* stringstream lineStream;
    string lineOut;

    // Check for Rst assertion
    lineStream << "\tif (Rst) begin";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);

    // Done and State are in every Verilog file
    lineStream << "\t\tDone <= 1'b0;";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);

    lineStream << "\t\tState <= WAIT;";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);

    // Reset all other registers and outputs
    for (vector<CircuitSignal>::iterator it = signals.begin(); it != signals.end(); ++it)
    {
        string signalType = it->getCircuitSignalType();
        if (signalType == "output" or signalType == "variable")
        {
            lineStream << "\t\t" << it->getCircuitSignalName() << " <= " << it->getCircuitSignalWidth() << "'b0;";
            lineOut = lineStream.str();
            stateMachine.push_back(lineOut);
        }
    }*/
}

void Process::createStateMachine(vector<CircuitComp> &components, vector<CircuitSignal> &signals, list<string> &stateMachine)
{
  /*  int stateNum = 0;
    int vecSize = static_cast<int>(ceil(log2(static_cast<double>(latency))));
    stringstream lineStream;
    string lineOut;
    string lineTabs;
    string opSymbol;
    string result;
    string op1;
    string op2;
    string sel;
    bool ifFound = false;
    bool elseFound = false;
    bool ifDeclared = false;
    bool elseDeclared = false;
    map<int, bool> ifLevelMap;
    map<int, bool> elseLevelMap;

    lineStream << "\tend else begin";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);

    createWaitState(stateMachine);

    // Determine what happens in each state
    for (int i = 0; i < numStates; ++i)
    {
        lineStream << "\t\tS" << i << " :";
        lineOut = lineStream.str();
        stateMachine.push_back(lineOut);

        lineStream << "\t\t\tbegin";
        lineOut = lineStream.str();
        stateMachine.push_back(lineOut);

        // Build state machine according to start times
        for (set<int>::iterator it2 = startTimeSet.begin(); it2 != startTimeSet.end(); ++it2)
        {
            stateNum = distance(startTimeSet.begin(), it2);
            lineStream << "\t\tS" << (stateNum - 1) << " :";
            lineOut = lineStream.str();
            stateMachine.push_back(lineOut);

            lineStream << "\t\t\tbegin";
            lineOut = lineStream.str();
            stateMachine.push_back(lineOut);

            lineStream << "\t\t\t\tif (CycleCnt == " << vecSize << "'d" << *it2 << " begin";
            lineOut = lineStream.str();
            stateMachine.push_back(lineOut);

            // Place components in the currently selected time slot
            for (vector<CircuitComp>::iterator it = components.begin(); it != components.end(); ++it)
            {
                if (it->timeframe[0] == *it2)
                {
                    convertComp(*it, opSymbol, result, op1, op2, sel);
                    
                    lineTabs = "\t\t\t\t\t";

                    // Is the current component part of an if statement? Then check if
                    // the if statement has been written. Write it if needed.
                    if (it->ifStatementLevel > 0)
                    {
                        for (map<int, bool>::iterator it3 = ifLevelMap.begin(); ((it3 != ifLevelMap.end()) && (!ifFound)); ++it3)
                        {
                            if (it->ifStatementLevel == it3->first())
                            {
                                ifFound = true;
                            }
                            if (ifFound && (it3->second() == false))
                            {
                                for (vector<CircuitSignal>::iterator csit = signals.begin(); csit != signals.end(); ++csit)
                                {
                                    if ((csit->getCircuitSignalIfCondition() == true) && (csit->getCircuitSignalIfConditionLevel == it->ifStatementLevel))
                                    {
                                        lineStream << lineTabs << "if (" << csit->getCircuitSignalName() << ") begin";
                                    }
                                }
                                it3->second() == true;
                            }
                        }

                        if (!ifFound)
                        {
                            for (vector<CircuitSignal>::iterator csit = signals.begin(); csit != signals.end(); ++csit)
                            {
                                if ((csit->getCircuitSignalIfCondition() == true) && (csit->getCircuitSignalIfConditionLevel == it->ifStatementLevel))
                                {
                                    lineStream << lineTabs << "if (" << csit->getCircuitSignalName() << ") begin";
                                    lineOut = lineStream.str();
                                    stateMachine.push_back(lineOut);
                                }
                            }
                            ifLevelMap.insert(pair<int, bool>(it->ifStatementLevel, true));
                        }
                    }

                    // Is the current component part of an else statement? Then check if
                    // the else statement has been written. Write it if needed.
                    if (it->elseStatementLevel > 0)
                    {
                        for (map<int, bool>::iterator it4 = elseLevelMap.begin(); ((it4 != elseLevelMap.end()) && (!ifFound)); ++it4)
                        {
                            if (it->elseStatementLevel == it4->first())
                            {
                                elseFound = true;
                            }
                            if (elseFound && (it3->second() == false))
                            {
                                lineStream << lineTabs << "end else begin";
                                lineOut = lineStream.str();
                                stateMachine.push_back(lineOut);
                                it3->second() == true;
                            }
                        }

                        if (!elseFound)
                        {
                            lineStream << lineTabs << "end else begin";
                            lineOut = lineStream.str();
                            stateMachine.push_back(lineOut);
                            elseLevelMap.insert(pair<int, bool>(it->elseStatementLevel, true));
                        }
                    }

                    // Write Verilog equivalent of component
                    if (!sel.empty())
                    {
                        lineStream << lineTabs << "\tif (" << sel << ") " << result << " <= " << op1 << ";";
                        lineOut = lineStream.str();
                        stateMachine.push_back(lineOut);

                        lineStream << lineTabs << "\telse " << result << " <= " << op2 << ";";
                        lineOut = lineStream.str();
                        stateMachine.push_back(lineOut);
                    }
                    else if (it->type.find("COMP") != string::npos)
                    {
                        lineStream << lineTabs << "\tif (" << op1 << " " << opSymbol << " " << op2 << ") " << result << " <= 1'b1;";
                        lineOut = lineStream.str();
                        stateMachine.push_back(lineOut);

                        lineStream << lineTabs << "\telse " << result << " << 1'b0;";
                        lineOut = lineStream.str();
                        stateMachine.push_back(lineOut);
                    }
                    else
                    {
                        lineStream << lineTabs << "\t" << result << " <= " << op1 << " " << opSymbol;
                        if (!op2.empty()) lineStream << " " << op2;
                        lineStream << ";";
                        lineOut = lineStream.str();
                        stateMachine.push_back(lineOut);
                    }
                }

                if (next(it, 1) == components.end())
                {
                    // close if or else block
                    if (it->ifStatementLevel > 0)
                    {
                        lineStream << lineTabs << "end";
                        lineOut = lineStream.str();
                        stateMachine.push_back(lineOut);

                        map<int, bool>::iterator iflm = ifLevelMap.find(it->ifStatementLevel);
                        iflm->second = false;
                    }
                    else if (it->elseStatementLevel > 0)
                    {
                        lineStream << lineTabs << "end";
                        lineOut = lineStream.str();
                        stateMachine.push_back(lineOut);

                        map<int, bool>::iterator elselm = elseLevelMap.find(it->elseStatementLevel);
                        elselm->second = false;
                    }

                    // find next state
                    if (next(it2, 1) = startTimeSet.end())
                    {
                        lineStream << lineTabs << "State <= FINAL;";
                    }
                    else
                    {
                        lineStream << lineTabs << "State <= S" << stateNum << ";";
                    }
                    lineOut = lineStream.str();
                    stateMachine.push_back(lineOut);
                }
            } // end loop through components
            // close the if cycle time = start time block
            lineStream << "\t\t\t\tend";
            lineOut = lineStream.str();
            stateMachine.push_back(lineOut);

            // always increment the cycle counter
            lineStream << "\t\t\t\tCycleCnt <= CycleCnt + 1;";
            lineOut = lineStream.str();
            stateMachine.push_back(lineOut);

            // close the current state
            lineStream << "\t\t\tend";
            lineOut = lineStream.str();
            stateMachine.push_back(lineOut);
        } // end loop through start times
    } // end loop through number of states

    createFinalState(stateMachine);*/
}

void Process::createWaitState(list<string> &stateMachine)
{
  /*  stringstream lineStream;
    string lineOut;

    lineStream << "\t\tcase (State)";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);

    // Wait for the Start signal
    lineStream << "\t\tWAIT :";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);
    
    lineStream << "\t\t\tbegin";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);
    
    lineStream << "\t\t\t\tDone <= 1'b0;";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);
    
    lineStream << "\t\t\t\tif (Start) begin";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);
    
    lineStream << "\t\t\t\t\tState <= S0;";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);

    lineStream << "\t\t\t\tend";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);
    
    lineStream << "\t\t\tend";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);*/
}

void Process::convertComp(CircuitComp &component, string &opSymbol, string &result, string &op1, string &op2, string &sel)
{
	/*
    opSymbol.clear();
    result.clear();
    op1.clear();
    op2.clear();
    sel.clear();

    if (component.type.find("ADD") != string::npos)
    {
        opSymbol = "+";
    }
    else if (component.type.find("SUB") != string::npos)
    {
        opSymbol = "-";
    }
    else if (component.type.find("MUL") != string::npos)
    {
        opSymbol = "*";
    }
    else if (component.type.find("COMP") != string::npos)
    {
        if (component.comparatorOp == GT)
        {
            opSymbol = ">";
        }
        else if (component.comparatorOp == LT)
        {
            opSymbol = "<";
        }
        else
        {
            opSymbol = "==";
        }
    }
    else if (component.type.find("SHR") != string::npos)
    {
        opSymbol = ">>";
    }
    else if (component.type.find("SHL") != string::npos)
    {
        opSymbol = "<<";
    }
    else if (component.type.find("DIV") != string::npos)
    {
        opSymbol = "/";
    }
    else if (component.type.find("MOD") != string::npos)
    {
        opSymbol = "%";
    }
    else if (component.type.find("INC") != string::npos)
    {
        opSymbol = "+ 1";
    }
    else if (component.type.find("DEC") != string::npos)
    {
        opSymbol = "- 1";
    }

    for (vector<CircuitSignal>::iterator it = component.operands.begin(); it != component.operands.end(); ++it)
    {
        if ((component.type.find("INC") != string::npos) ||
            (component.type.find("DEC") != string::npos))
        {
            if (it->getCircuitSignalPosition() == "result")
            {
                result = it->getCircuitSignalName();
            }
            else if (it->getCircuitSignalPosition() == "op1")
            {
                op1 = it->getCircuitSignalName();
            }
        }
        else if (component.type.find("MUX") != string::npos)
        {
            if (it->getCircuitSignalPosition() == "result")
            {
                result = it->getCircuitSignalName();
            }
            else if (it->getCircuitSignalPosition() == "sel")
            {
                sel = it->getCircuitSignalName();
            }
            else if (it->getCircuitSignalPosition() == "op1")
            {
                op1 = it->getCircuitSignalName();
            }
            else if (it->getCircuitSignalPosition() == "op2")
            {
                op2 = it->getCircuitSignalName();
            }
        }
        else if (component.type.find("COMP") != string::npos)
        {
            if (((component.comparatorOp == GT) && (it->getCircuitSignalPosition() == "op3")) ||
                ((component.comparatorOp == LT) && (it->getCircuitSignalPosition() == "op4")) ||
                ((component.comparatorOp == EQ) && (it->getCircuitSignalPosition() == "op5")))
            {
                result = it->getCircuitSignalName();
            }
            else if (it->getCircuitSignalPosition() == "op1")
            {
                op1 = it->getCircuitSignalName();
            }
            else if (it->getCircuitSignalPosition() == "op2")
            {
                op2 = it->getCircuitSignalName();
            }
        }
        else
        {
            if (it->getCircuitSignalPosition() == "result")
            {
                result = it->getCircuitSignalName();
            }
            else if (it->getCircuitSignalPosition() == "op1")
            {
                op1 = it->getCircuitSignalName();
            }
            else if (it->getCircuitSignalPosition() == "op2")
            {
                op2 = it->getCircuitSignalName();
            }
        }
    }*/
}

void Process::createFinalState(list<string> &stateMachine)
{
  /*  stringstream lineStream;
    string lineOut;

    // Wait for the latency
    lineStream << "\t\tFINAL :";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);

    lineStream << "\t\t\tbegin";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);

    // Find latest end time
    for (vector<CircuitComp>::iterator it = components.begin(); it != components.end(); ++it)
    {
        for (set<int>::iterator it2 = endTimeSet.begin(); (it2 != endTimeSet.end() && !foundEntry); ++it2)
        {
            if (it->timeframe[1] == *it2)
            {
                foundEntry = true;
            }
        }

        if (!foundEntry)
            endTimeSet.insert(it->timeframe[1]);

        foundEntry = false;
    }

    set<int>::iterator etit = endTimeSet.rbegin();
    lineStream << "\t\t\t\tif (CycleCnt == " << *etit << ") begin";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);

    lineStream << "\t\t\t\t\tDone <= 1'b1;";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);
    
    lineStream << "\t\t\t\t\tState <= WAIT;";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);

    lineStream << "\t\t\t\tend"
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);

    lineStream << "\t\t\t\tCycleCnt <= CycleCnt + 1;";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);
    
    lineStream << "\t\t\tend";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);

    lineStream << "\t\tendcase";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);
    
    lineStream << "\tend";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);
    
    lineStream << "end";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);
    
    lineStream << "endmodule";
    lineOut = lineStream.str();
    stateMachine.push_back(lineOut);*/
}

void Process::setVerilogFilename(const char *vFilename)
{
    string inVerilogFilename(vFilename);
	string::size_type pos = inVerilogFilename.find_last_of('/');
	if( pos != string::npos)
	{
		verilogFilename = inVerilogFilename.substr(pos+1, inVerilogFilename.length());
	}
	else
	{
		verilogFilename = inVerilogFilename;
	}
}

double Process::addDependentDelaysOneOP(vector<CircuitComp> &circuitCompVector, string op1) //add passing in vector
{
	double addedDelay = 0;
	
	for (vector<int>::size_type i = 0; i != circuitCompVector.size(); i++)
	{
		if (op1 == circuitCompVector.at(i).result.getCircuitSignalName()) //if the current operand was ever a result then this component needs to "wait" for that instantiation
		{
			//set the added delay based on the current component instantiations' data width and type
						//addedDelay = delays.stringToDelay(circuitCompVector.at(i).type, circuitCompVector.at(i).width);
            if(circuitCompVector.at(i).delay > addedDelay)
                addedDelay = circuitCompVector.at(i).delay;
			//cout<<"Found dependency, adding " << addedDelay << "ns" << " Type: " << circuitCompVector.at(i).type << " OP: " << op1 << endl; //TODO Remove DEBUG print
		}
	}
	
	return addedDelay;
}

//NOTE: Also use for COMP since we only need to look at two operands
double Process::addDependentDelaysTwoOP(vector<CircuitComp> &circuitCompVector, string op1, string op2)
{
	double addedDelay = 0;
	for (vector<int>::size_type i = 0; i != circuitCompVector.size(); i++) //check Comp Vector if there's a dependency on op1
	{
		if (op1 == circuitCompVector.at(i).result.getCircuitSignalName()) //if the current operand was ever a result then this component needs to "wait" for that instantiation
		{
			//set the added delay based on the current component instantiations' data width and type
						//addedDelay = delays.stringToDelay(circuitCompVector.at(i).type, circuitCompVector.at(i).width);
            if(circuitCompVector.at(i).delay > addedDelay)
                addedDelay = circuitCompVector.at(i).delay;
			//cout<<"Found dependency, adding " << addedDelay << "ns" << " Type: " << circuitCompVector.at(i).type << " OP: " << op1 << endl; //TODO Remove DEBUG print
		}
	}
	
	for (vector<int>::size_type i = 0; i != circuitCompVector.size(); i++) //check Comp Vector if there's a dependency on op2
	{
		if (op2 == circuitCompVector.at(i).result.getCircuitSignalName()) //if the current operand was ever a result then this component needs to "wait" for that instantiation
		{
			//set the added delay based on the current component instantiations' data width and type
						//addedDelay = delays.stringToDelay(circuitCompVector.at(i).type, circuitCompVector.at(i).width);
           if(circuitCompVector.at(i).delay > addedDelay)
                addedDelay = circuitCompVector.at(i).delay;
			//cout<<"Found dependency, adding " << addedDelay << "ns" <<  " Type: " << circuitCompVector.at(i).type << " OP: " << op2 << endl; //TODO Remove DEBUG print
		}
	}
	
	return addedDelay;
}

double Process::addDependentDelaysMux(vector<CircuitComp> &circuitCompVector, string op1, string op2, string op3)
{
	double addedDelay = 0;
	for (vector<int>::size_type i = 0; i != circuitCompVector.size(); i++) //check Comp Vector if there's a dependency on op1
	{
		if (op1 == circuitCompVector.at(i).result.getCircuitSignalName()) //if the current operand was ever a result then this component needs to "wait" for that instantiation
		{
			//set the added delay based on the current component instantiations' data width and type
						//addedDelay = delays.stringToDelay(circuitCompVector.at(i).type, circuitCompVector.at(i).width);
            if(circuitCompVector.at(i).delay > addedDelay)
                addedDelay = circuitCompVector.at(i).delay;
			//cout<<"Found dependency, adding " << addedDelay << "ns" << " Type: " << circuitCompVector.at(i).type << " OP1: " << op1 << endl; //TODO Remove DEBUG print
		}
	}
	
	for (vector<int>::size_type i = 0; i != circuitCompVector.size(); i++) //check Comp Vector if there's a dependency on op2
	{
		if (op2 == circuitCompVector.at(i).result.getCircuitSignalName()) //if the current operand was ever a result then this component needs to "wait" for that instantiation
		{
			//set the added delay based on the current component instantiations' data width and type
						//addedDelay = delays.stringToDelay(circuitCompVector.at(i).type, circuitCompVector.at(i).width);
            if(circuitCompVector.at(i).delay > addedDelay)
                addedDelay = circuitCompVector.at(i).delay;
			//cout<<"Found dependency, adding " << addedDelay << "ns" << " Type: " << circuitCompVector.at(i).type << " OP2: " << op2 << endl; //TODO Remove DEBUG print
		}
	}
	
	for (vector<int>::size_type i = 0; i != circuitCompVector.size(); i++) //check Comp Vector if there's a dependency on op2
	{
		if (op3 == circuitCompVector.at(i).result.getCircuitSignalName()) //if the current operand was ever a result then this component needs to "wait" for that instantiation
		{
			//set the added delay based on the current component instantiations' data width and type
			//addedDelay = delays.stringToDelay(circuitCompVector.at(i).type, circuitCompVector.at(i).width);
            if(circuitCompVector.at(i).delay > addedDelay)
                addedDelay = circuitCompVector.at(i).delay;
			//cout<<"Found dependency, adding " << addedDelay << "ns" << " Type: " << circuitCompVector.at(i).type << " OP3: " << op3 <<endl; //TODO Remove DEBUG print
		}
	}
	
	return addedDelay;
}

//loops through the Comp vector to find the element with the largest delay time and returns that time
double Process::CalculateCriticalPath(vector<CircuitComp> &circuitCompVector)
{
	for (vector<int>::size_type i = 0; i != circuitCompVector.size(); i++)
	{
		if((circuitCompVector.at(i).type == "INC") || (circuitCompVector.at(i).type == "DEC") || (circuitCompVector.at(i).type == "REG") 
            || (circuitCompVector.at(i).type == "SINC") || (circuitCompVector.at(i).type == "SDEC") || (circuitCompVector.at(i).type == "SREG"))
		{
			string input1, input2;
            
            if(circuitCompVector.at(i).operands.at(0).getCircuitSignalName() != circuitCompVector.at(i).result.getCircuitSignalName())
            {
                input1 = circuitCompVector.at(i).operands.at(0).getCircuitSignalName();
            }
            else
            {
                input1 = circuitCompVector.at(i).operands.at(1).getCircuitSignalName();
            }
			
           // cout << circuitCompVector.at(i).type << " "<< input1 << endl;
			circuitCompVector.at(i).delay += addDependentDelaysOneOP(circuitCompVector, input1);
           // cout << "New delay: " << circuitCompVector.at(i).delay << endl;
		}
		else if((circuitCompVector.at(i).type == "MUX") || (circuitCompVector.at(i).type == "SMUX"))
		{
            string input1, input2, input3;
            
            if(circuitCompVector.at(i).operands.at(0).getCircuitSignalName() != circuitCompVector.at(i).result.getCircuitSignalName())
            {
                input1 = circuitCompVector.at(i).operands.at(0).getCircuitSignalName();
                if(circuitCompVector.at(i).operands.at(1).getCircuitSignalName() != circuitCompVector.at(i).result.getCircuitSignalName())
                {
                    input2 = circuitCompVector.at(i).operands.at(1).getCircuitSignalName();
                    if(circuitCompVector.at(i).operands.at(2).getCircuitSignalName() != circuitCompVector.at(i).result.getCircuitSignalName())
					{
						input3 = circuitCompVector.at(i).operands.at(2).getCircuitSignalName();
					}
					else
					{
						input3 = circuitCompVector.at(i).operands.at(3).getCircuitSignalName();
					}
                }
                else
                {
                    input2 = circuitCompVector.at(i).operands.at(2).getCircuitSignalName();
                    input3 = circuitCompVector.at(i).operands.at(3).getCircuitSignalName();
                }
            }
            else
            {
                input1 = circuitCompVector.at(i).operands.at(1).getCircuitSignalName();
                input2 = circuitCompVector.at(i).operands.at(2).getCircuitSignalName();
                input3 = circuitCompVector.at(i).operands.at(3).getCircuitSignalName();
            }
           // cout << circuitCompVector.at(i).type << " "<< input1 << " "<< input2 << " "<< input3 << endl;
			circuitCompVector.at(i).delay += addDependentDelaysMux(circuitCompVector, input1, 
												input2, input3) ;
           // cout << "New delay: " << circuitCompVector.at(i).delay << endl;                                            
		}
		else
		{
			string input1, input2;
            
            if(circuitCompVector.at(i).operands.at(0).getCircuitSignalName() != circuitCompVector.at(i).result.getCircuitSignalName())
            {
                input1 = circuitCompVector.at(i).operands.at(0).getCircuitSignalName();
                if(circuitCompVector.at(i).operands.at(1).getCircuitSignalName() != circuitCompVector.at(i).result.getCircuitSignalName())
                {
                    input2 = circuitCompVector.at(i).operands.at(1).getCircuitSignalName();
                }
                else
                {
                    input2 = circuitCompVector.at(i).operands.at(2).getCircuitSignalName();
                }
            }
            else
            {
                input1 = circuitCompVector.at(i).operands.at(1).getCircuitSignalName();
                input2 = circuitCompVector.at(i).operands.at(2).getCircuitSignalName();
            }
			
            // cout << circuitCompVector.at(i).type << " "<< input1 << " "<< input2 << endl;
			circuitCompVector.at(i).delay += addDependentDelaysTwoOP(circuitCompVector, input1, input2) ;
           // cout << "New delay: " << circuitCompVector.at(i).delay << endl;
        }
	}
	double maxTime = 0;
	for (vector<int>::size_type i = 0; i != circuitCompVector.size(); i++) 
	{
		if(circuitCompVector.at(i).delay > maxTime)
			maxTime = circuitCompVector.at(i).delay;
	}
	
	return maxTime;
	
}

int Process::stringToEnumType(string datatype)
{
	int enumType = -1;
	
	if ((datatype == "ADD") || (datatype == "SUB") || (datatype == "INC" ) || (datatype == "DEC"))
	{
		enumType = 2;
	}
	else if ((datatype == "MUL"))
	{
		enumType = 0;
	}
	else if ((datatype == "DIV") || (datatype == "MOD"))
	{
		enumType = 1;
	}
	else if ((datatype == "COMP") || (datatype == "MUX") || (datatype == "SHR") || (datatype == "SHL"))
	{
		enumType = 3;
	}
	
	return enumType;
}

int Process::getCycleTime(string datatype)
{
	int cycle = -1;
	
	if ((datatype == "ADD") || (datatype == "SUB") || (datatype == "INC" ) || (datatype == "DEC"))
	{
		cycle = 1;
	}
	else if ((datatype == "MUL"))
	{
		cycle = 2;
	}
	else if ((datatype == "DIV") || (datatype == "MOD"))
	{
		cycle = 3;
	}
	else if ((datatype == "COMP") || (datatype == "MUX") || (datatype == "SHR") || (datatype == "SHL"))
	{
		cycle = 1;
	}
	
	return cycle;
}
