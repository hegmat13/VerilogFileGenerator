Name                NETID              Course    Contributions
--------------------------------------------------------------------------------- 
Nathan Devine       ndevine            ECE574    Parsing/FDS/Debugging/Testing
Alex Blackmon       alexblackmon       ECE574    ASAP_ALAP/Debugging/Testing
John Blair          jablair            ECE574    Verilog File Generation/Debugging/Testing
Chris Johnson       electrofier        ECE474    ASAP_ALAP/Debugging/Testing
Description
----------------------------------------------
hlsyn is a C++ synthesizer which converts a C-like behavioral description into a
scheduled high-level statement machine implemented in Verilog.
It takes an input file which details the 
inputs/outputs/wires/registers and the various
components, then will output the correct verilog
file. 

