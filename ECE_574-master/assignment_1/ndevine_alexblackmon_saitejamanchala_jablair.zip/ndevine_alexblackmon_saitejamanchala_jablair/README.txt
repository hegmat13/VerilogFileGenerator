1. Names and NetID's

Name                        NetID
Nathan Devine               ndevine
Alex Blackmon               alexblackmon
Sai Teja Manchala           saitejamanchala
John Blair                  jablair

2. Xylinx Synthesis Tool Version: 2018.2.1
   Target FPGA: xc7a100tcsg324(Atrix-7)
   Speed Grade: -3
   
3. Critical Path Calculation

After running the synthesis with out_of_context mode set, the schematic diagram of the circuit is obtained. 
The longest delay from the timing simulation is higlighted and the critical path is shown on the schematic. 
The estimated critical path was calculated utilizing the schematic and determing which input would cause 
the longest delay (based on individual component delays) before the component had all needed inputs, with 
each output of the componenets having the delay of the longest input plus its own delay.
   

                            
